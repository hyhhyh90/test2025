#! /bin/bash

PACKAGE=$1
VERSION=$2

ROOT=/usr/cg
BM_ROOT=/usr/cg/bm
BM_TEMP=/usr/cg/temp
BM_BACKUP=/usr/cg/bm-bak
UPDATE_LOG=/usr/cg/update.log
XML_CONFIG_FILE=bm_agent_config.xml
XML_CONFIG_FILE_TEMP=bm_agent_config_temp.xml

cd $ROOT

function clean() {
    sudo rm -rf $BM_BACKUP
    sudo rm -rf $BM_TEMP
}

function back() {
    sudo cp -r bm-bak bm
}

function updateXML() {

    sudo mv $BM_ROOT/$XML_CONFIG_FILE $BM_ROOT/$XML_CONFIG_FILE_TEMP

    line=$(grep -n '<version>' $BM_ROOT/$XML_CONFIG_FILE_TEMP | cut -d":" -f1)

    echo "update version:$VERSION"

    sudo sed "${line}s/.*/<version>$VERSION<\/version>/" $BM_ROOT/$XML_CONFIG_FILE_TEMP>$BM_ROOT/$XML_CONFIG_FILE

    if [ -f "$BM_ROOT/$XML_CONFIG_FILE" ]; then
        echo "update xml file ok"
        sudo rm $BM_ROOT/$XML_CONFIG_FILE_TEMP
    else
        echo "update xml config file failed, use old file"
        sudo mv $BM_ROOT/$XML_CONFIG_FILE_TEMP $BM_ROOT/$XML_CONFIG_FILE
    fi
}

clean

sudo mkdir -p $BM_TEMP

sudo cp -r bm bm-bak

sudo tar -xvf $PACKAGE -C $BM_TEMP --strip-components 1
if [ $? -ne 0 ]; then
    echo "Failed uncompress new package:$PACKAGE." >> $UPDATE_LOG
    back
    exit -1
fi

sudo mv $BM_TEMP/bm/bm-agent $BM_ROOT/
sudo mv $BM_TEMP/bm/librespeed-cli  $BM_ROOT/
sudo mv $BM_TEMP/bm/update.sh  $BM_ROOT/
sudo mv $BM_TEMP/bm/run.sh   $BM_ROOT/

sudo chmod -R a+rwx bm

clean

updateXML

echo "update new package success, package:$PACKAGE, version:$VERSION" >> $UPDATE_LOG

exit 0