#!/bin/bash

ROOT_FOLDER=/usr/cg
ROOT_PATH=/usr/cg/bm
SERVICE_NAME="bm-agent"
SERVICE_DESC="bm agent"

cd $ROOT_PATH

echo $ROOT_PATH

STARTPATAM="-ak $1 -sk $2 -serverName $3 -home $4"

if [ $# -eq 5 ]; then
    STARTPATAM="-ak $1 -sk $2 -serverName $3 -home $4 -cs $5"
fi

EXECUTABLE_PATH="${ROOT_PATH}/bm-agent & $STARTPATAM"

echo $EXECUTABLE_PATH

function start_service() {
    cat << EOF > "/etc/systemd/system/$SERVICE_NAME.service"
[Unit]
Description=$SERVICE_DESC
After=network.target

[Service]
Type=simple
ExecStart=$EXECUTABLE_PATH
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

  sudo systemctl enable $SERVICE_NAME
  sudo systemctl start $SERVICE_NAME
}

start_service

